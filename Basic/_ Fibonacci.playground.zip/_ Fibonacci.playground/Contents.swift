/*
    費式數列(Fibonacci)的求法，有多種形式可以表達
    例如：指定5，它要計算出(5*4*3*2*1)的總和
 */

// #1 最簡單好用的方法
func _calculate1(_ num:Int) -> Int{
    return (1...num).reduce(1, *)
}

print(_calculate1(4))


// #2 if/else的遞迴拆解
func _calculate2(_ num:Int) -> Int{
    if num == 1{
        return 1
    } else {
        return num * _calculate1(num - 1)
    }
}

print(_calculate2(4))

// #3 for的遞迴拆解
func _calculate3(_ num:Int) -> Int{
    var sum = 1
    for i in 1...num{
        sum = sum * i
        //print(sum)
    }
    return sum
}

print(_calculate3(4))
