import UIKit

var _array = ["A","B","C","D","E"]
print(_array[4])

print(_array.count)

_array.append("F")
print(_array)

// 將G插入在第6筆
_array.insert("G", at: 6)
print(_array)

// 刪除特定資料
_array.remove(at: 6)
print(_array)

// 刪除最後一個
_array.removeLast()
print(_array)

// 刪除第一個
_array.removeFirst()
print(_array)

// 反排序
_array.reverse()
print(_array)

// 反排序，只影響呼叫的那一行順序,不影響原陣列順序
_array.reversed()

// 正排序
_array.sort()
print(_array)

/*
    1.典型Array儲存的型態必須一致，否則會出現問題
    2.如果要使用任意儲存型態，可以使用[Any]的方式
 
 */
var temp:[Any] = ["1",2,"3",4]
print(type(of: temp[0]))
print(type(of: temp[1]))

// 宣告儲存String的空陣列
var strArray:[String] = []
var strArray2 = [String]() //另一種寫法

// 宣告儲存Int的空陣列
var intArray:[Int] = []
var intArray2 = [Int]() // 另一種寫法，同上





